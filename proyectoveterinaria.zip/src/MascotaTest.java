public class MascotaTest
    {
    public void runTest(){
        testGetNombre();
    }
    private static void testGetNombre(){
        Mascota mascota = new Mascota("max",12, "perro","jose-castro", "6688282838" );
        if(mascota.getNombre() == "max"){
            System.out.println("Test tesGetNombre: OK");
        }
        else{
            System.out.println("Test testGetNombre: No OK");
        }
    }
}
