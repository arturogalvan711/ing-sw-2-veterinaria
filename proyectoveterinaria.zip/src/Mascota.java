public class Mascota {
    private final String nombre;
    private final int edad;
    private final String especie;
    private final String nom_propetario;
    private final String num_propetario;

    // Constructor
    public Mascota(String nombre, int edad, String especie, String nom_propetario, String num_propetario) {
        this.nombre = nombre;
        this.edad = edad;
        this.especie = especie;
        this.nom_propetario=nom_propetario;
        this.num_propetario=num_propetario;
    }

    // Getters
    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }


    // Representación en texto
    @Override
    public String toString() {
        return " Nombre: " + nombre + "\n Edad: " + edad +
                "\n Especie: " + especie + "\n nombre del propietario: "
                +nom_propetario+
                "\n numero del propietario: "+num_propetario;
    }
}

