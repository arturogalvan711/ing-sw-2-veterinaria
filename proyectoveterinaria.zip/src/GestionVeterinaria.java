import java.util.ArrayList;

public class GestionVeterinaria {
    private ArrayList<Mascota> mascotas;

    // Constructor
    public GestionVeterinaria() {
        mascotas = new ArrayList<>();
    }

    // Agregar una mascota
    public void agregarMascota(Mascota mascota) {
        mascotas.add(mascota);
        System.out.println("Mascota agregada exitosamente: " + mascota.getNombre());
    }

    // Mostrar todas las mascotas
    public void mostrarMascotas() {
        if (mascotas.isEmpty()) {
            System.out.println("No hay mascotas registradas.");
            return;
        }
        System.out.println("Lista de mascotas:");
        for (Mascota mascota : mascotas) {
            System.out.println(mascota);
        }
    }

    // Eliminar una mascota por nombre
    public void eliminarMascota(String nombre) {
        boolean eliminada = mascotas.removeIf(mascota -> mascota.getNombre().equalsIgnoreCase(nombre));
        if (eliminada) {
            System.out.println("Mascota eliminada: " + nombre);
        } else {
            System.out.println("No se encontró una mascota con el nombre: " + nombre);
        }
    }
}

