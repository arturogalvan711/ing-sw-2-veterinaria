import java.util.Scanner;

public class Menu {
    private GestionVeterinaria sistema;
    Scanner scanner = new Scanner(System.in);

    // Constructor
    public Menu() {
        sistema = new GestionVeterinaria();
    }

    // Mostrar el menú e interactuar con el usuario
    public void mostrarMenu() {
        String res = "";
        do {
                System.out.println("\n---- Menú Veterinaria ----");
                System.out.println("1. Agregar mascota");
                System.out.println("2. Mostrar mascotas");
                System.out.println("3. Eliminar mascota");
                System.out.println("4. Salir");
                System.out.print("Seleccione una opción: ");
                int opcion = scanner.nextInt();

                switch (opcion) {
                    case 1:
                        agregarMascota();
                        break;
                    case 2:
                        sistema.mostrarMascotas();
                        break;
                    case 3:
                        eliminarMascota();
                        break;
                    case 4:
                        System.out.println("¡Gracias por usar el sistema de la veterinaria!");
                        scanner.close();
                        return; // Salir del programa
                    default:
                        System.out.println("Opción inválida. Intente nuevamente.");
                }
                scanner.nextLine();
            System.out.println("Quieres realizar otra operacion (s/n)");
            res = scanner.nextLine();
        }while (res.equals("s"));
    }

    // Métodos auxiliares para las opciones
    private void agregarMascota() {
        System.out.print("Nombre de la mascota: ");
        String nombre = scanner.next();
        System.out.print("Edad de la mascota: ");
        int edad = scanner.nextInt();
        System.out.print("Especie de la mascota: ");
        String especie = scanner.next();
        System.out.println("Nombre del dueño: ");
        String nom_propietario = scanner.next();
        System.out.println("Numero del dueño: ");
        String num_propietario = scanner.next();



        Mascota mascota = new Mascota(nombre, edad, especie,nom_propietario, num_propietario);
        sistema.agregarMascota(mascota);
    }

    private void eliminarMascota() {
        System.out.print("Nombre de la mascota a eliminar: ");
        String nombre = scanner.next();
        sistema.eliminarMascota(nombre);
    }

}

